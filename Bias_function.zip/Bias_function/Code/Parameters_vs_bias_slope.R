rm(list = ls() )

# library(AICcmodavg)
# library(plyr)
# library(stringr)
library(ggpubr)
library(sjPlot)
library(sjmisc)
library(sjlabelled)
library(ggplot2)
library(snakecase)

sample_size <- read.csv('samplesize.csv')
attach(sample_size)


### bias of slope and sample size
sample_size.lm.slope <- lm(bias.slope ~log( Sample.size) )
summary(sample_size.lm.slope)
tab_model(sample_size.lm.slope )

graphics.off()
plot(Sample.size, bias.slope, main = 'Sample size Vs Bias of Slope')
lines(lowess(bias.slope ~ Sample.size), col = 'red', lwd= 2)
dev.copy(pdf, 'sample_size_vs_bias_slope.pdf', width = 8, height = 5)
dev.off()
abline(sample_size.lm.slope, col = 'red')


sample_size_data <- data.frame(Sample.size, bias.slope)
plot(sample_size_data)
lines(sample_size_data, col = 'red')


### correlation test
# scatter plot
library("ggpubr")
ggscatter(sample_size, x = "bias.slope", y = "Sample.size", 
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Sample Size", ylab = "Bias of slope")


#varying true slope
#############################################################################
#############################################################################
rm(list = ls())
slope_data <- read.csv('slopedata.csv')
slope_data <- subset(slope_data, bias.slope != '0')
attach(slope_data)

### bias of slope and sample size
slope_data.lm.slope <- lm(bias.slope ~ true.slope )
summary(slope_data.lm.slope)
tab_model(slope_data.lm.slope )
new <- data.frame(true.slope = c(10, -5, 3, 2, 0, 15)  )
predict(slope_data.lm.slope, new, interval = "prediction")

graphics.off()
plot(true.slope, bias.slope, main = 'True Slope Vs Bias of Slope')
lines(lowess(bias.slope ~ true.slope), col = 'red', lwd= 2)
#abline(slope_data.lm.slope, col = 'red', lwd = 2)
dev.copy(pdf, 'true_slope_vs_bias_slope.pdf', width = 8, height = 5)
dev.off()

sample_size_data <- data.frame(Sample.size, bias.slope)
plot(sample_size_data)
lines(sample_size_data, col = 'red')




### bias of slope and intercept
intercept_data <- read.csv('intercept.csv')
attach(intercept_data)

intercept_data.lm.slope <- lm(bias.slope ~ true.intercept )
summary(intercept_data.lm.slope)
tab_model(intercept_data.lm.slope )

graphics.off()
plot(true.intercept, bias.slope, main = 'True Intercept Vs Bias of Slope',
     ylim = c(-0.26,-0.1))
lines(lowess(bias.slope ~ true.intercept), col = 'red', lwd= 2)
dev.copy(pdf, 'varying_intercept.pdf', width = 8, height = 5)
dev.off()






### bias of slope and sigma_x
sigmax_data <- read.csv('sigmax.csv')
attach(sigmax_data)

sigmax.lm.slope <- glm(bias.slope ~ sigma.x )
summary(sigmax.lm.slope)
tab_model(sigmax.lm.slope )

graphics.off()
par(mfrow = c(1,2))
plot(sigma.x, bias.slope, main = 'A)  Sigma_x Vs Bias of Slope')
lines(lowess(bias.slope ~ sigma.x), col= 'red', lwd = 2)



### bias of slope and sigma_y
sigmay_data <- read.csv('sigmay.csv')
attach(sigmay_data)

plot(sigma.y, bias.slope,
            main = 'B)  Sigma_y Vs Bias of Slope')
lines(lowess(bias.slope ~ sigma.y), col= 'red', lwd = 2)
dev.copy(pdf, 'sigmax_sigmay.pdf', width = 8, height = 5)
dev.off()

