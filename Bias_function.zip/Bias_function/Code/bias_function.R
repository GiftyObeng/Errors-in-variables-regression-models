rm(list = ls())

library(ggpubr)
library(sjPlot)
library(sjmisc)
library(sjlabelled)
library(ggplot2)
library(snakecase)
library(mgcv)

all_para <- read.csv('varying_parameters_separately.csv')
View(all_para)
attach(all_para)

all.sr <- lm( bias.slope ~ ((true.slope*sigma.x)/(log(Sample.size)*(sigma.x 
                              + sigma.y))) - true.slope/log(Sample.size) )
summary(all.sr)

##############################################
# generalised linear model for all paramters
all.glm <- glm(bias.slope ~ sigma.x + sigma.y + true.intercept+ true.slope)
summary(all.glm)


#linear model for all paramters
all.lm <- lm(bias.slope ~ sigma.x + sigma.y + true.intercept+ true.slope)
summary(all.lm)
tab_model(all.glm, all.lm)


###################### non linear model
slope.nlm <- lm(estimated.slope ~ (true.slope*sigma.x)/(sigma.x + sigma.y) )
summary(slope.nlm)

#######including sample size
slope.nlm2 <- lm(estimated.slope ~ (true.slope*sigma.x)/((sigma.x + 
                            sigma.y)*Sample.size) )
summary(slope.nlm2)

slope.nlm3 <- lm(estimated.slope ~ (true.slope*sigma.x)/((sigma.x +
                            sigma.y)*log(Sample.size)) )
summary(slope.nlm3)



## bias value
bias1 <- lm(bias.slope ~ (true.slope*sigma.x)/((sigma.x +
                       sigma.y)*log(Sample.size)) -true.slope  )
summary(bias1)

bias2 <- lm(bias.slope ~ (((true.slope*sigma.x)/(sigma.x +sigma.y))-
                            true.slope )/log(Sample.size) )
summary(bias2)
