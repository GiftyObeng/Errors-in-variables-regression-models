rm(list = ls())

### getting the 10 estimates for the 10,000 simulations
# x = seq(1:10)
# fix sigma_x = 1
# sigma_y = 1
# N = 1000, number of simulations


stepsize = 1
x <- seq(1, 10, stepsize)
sigma_x <- 1
sigma_y <- 1
mean_error_x <- 0
mean_error_y <- 0
num_of_rep <- 1000
n <- length(x)                                  # sample size
intercept <- 0.5                                       # intercept
slope <- 2                                        # slope of the model
y_predefined <- intercept + slope*x                       # dependent variable (predefined

mean_error_slope_xy <- numeric(length(x))
mean_error_intercept_xy <- numeric(length(x))
residual <- numeric(length(x))

for (i in 1:length(x)) {
  error_slope_xy <- numeric(num_of_rep)
  error_intercept_xy <- numeric(num_of_rep)

  for (k in 1:num_of_rep) {
    x_with_error = x + rnorm(n, mean_error_x, sigma_x)
    y_with_error = y_predefined + rnorm(n, mean_error_y, sigma_y)
    wzlm = lm (y_with_error ~ x_with_error)

    error_slope_xy[[k]] = as.vector( wzlm$coefficients[2])
    error_intercept_xy[[k]] = as.vector( wzlm$coefficients[1])
  }

  new_y <- mean(error_intercept_xy) + mean(error_slope_xy)*x
  fitted_line<- summary( lm(new_y ~ x) )
  residual[[i]] <- fitted_line$sigma

  mean_error_slope_xy[[i]] = as.vector( mean(error_slope_xy))
  mean_error_intercept_xy[[i]] = as.vector( mean(error_intercept_xy))
}

# appending the results into the data dframe

 columns <- c('bias of intercept','bias slope','estimated intercept',
             "estimated slope","Sample size", 'true intercept', "true slope", "sigma x",
             "sigma y", 'residuals')

bias_slope1 <- data.frame(mean_error_intercept_xy - intercept,mean_error_slope_xy -slope,
                          mean_error_intercept_xy,mean_error_slope_xy,
                          length(x),intercept, slope, sigma_x,
                          sigma_y, residual)
colnames(bias_slope1) <- columns
bias_slope1
nrow(bias_slope1)

write.csv(bias_slope1,'x.csv')



#####################################################3
#####################################################
###varying sigma_x

x <- seq(1, 10, stepsize)
sigma_x <- seq(0.1, 5, stepsize )
sigma_y <- 1
mean_error_x <- 0
mean_error_y <- 0
num_of_rep <- 1000
n <- length(sigma_x)                                  # sample size
intercept <- 0.5                                       # intercept
slope <- 2                                        # slope of the model
y_predefined <- intercept + slope*x                       # dependent variable (predefined

mean_error_slope_xy2 <- c()
mean_error_intercept_xy2 <- c()
#for (p in 1:length(sigma_x)) {
residual <- c()
for (i in sigma_x) {

  error_slope_xy2 <- numeric(num_of_rep)
  error_intercept_xy2 <- numeric(num_of_rep)
  for (k in 1:num_of_rep) {

    x_with_error = x + rnorm(length(x), mean_error_x, i)
    y_with_error = y_predefined + rnorm(length(x), mean_error_y, sigma_y)
    wzlm = lm (y_with_error ~ x_with_error)
    error_slope_xy2[[k]] = as.vector( wzlm$coefficients[2])
    error_intercept_xy2[[k]] <- as.vector(wzlm$coefficients[1])
  }

  new_y <- mean(error_intercept_xy2) + mean(error_slope_xy2)*x
  fitted_line<- summary( lm(new_y ~ x) )
  res <- fitted_line$sigma
  residual <- c(residual, res)

  mean_error_slope_xy2 <- c(mean_error_slope_xy2, mean(error_slope_xy2))
  mean_error_intercept_xy2 <- c(mean_error_intercept_xy2,
                                mean(error_intercept_xy2))
}

# appending the results into the data dframe
bias_slope2 <- data.frame(mean_error_intercept_xy2 - intercept,
                          mean_error_slope_xy2 -slope,
                          mean_error_intercept_xy2,mean_error_slope_xy2,
                          length(x),intercept, slope, sigma_x,
                          sigma_y, residual)
colnames(bias_slope2) <- columns

write.csv(bias_slope2,'sigma_x.csv')
nrow(bias_slope2)






############################################################
# changing sigma_y
x <- seq(1, 10, stepsize)
sigma_y <- seq(0.1, 5, stepsize )
sigma_x <- 1
mean_error_x <- 0
mean_error_y <- 0
num_of_rep <- 1000
n <- length(sigma_y)                                  # sample size
intercept <- 0.5                                       # intercept
slope <- 2                                        # slope of the model
y_predefined <- intercept + slope*x                       # dependent variable (predefined

mean_error_slope_xy3 <- c()
mean_error_intercept_xy3 <- c()
#for (p in 1:length(sigma_x)) {
residual <- c()
for (i in sigma_y) {

  error_slope_xy3 <- numeric(num_of_rep)
  error_intercept_xy3 <- numeric(num_of_rep)
  for (k in 1:num_of_rep) {

    x_with_error = x + rnorm(length(x), mean_error_x, sigma_x)
    y_with_error = y_predefined + rnorm(length(x), mean_error_y, i)
    wzlm = lm (y_with_error ~ x_with_error)
    error_slope_xy3[[k]] = as.vector( wzlm$coefficients[2])
    error_intercept_xy3[[k]] <- as.vector(wzlm$coefficients[1])
  }

  new_y <- mean(error_intercept_xy3) + mean(error_slope_xy3)*x
  fitted_line<- summary( lm(new_y ~ x) )
  res <- fitted_line$sigma
  residual <- c(residual, res)

  mean_error_slope_xy3 <- c(mean_error_slope_xy3, mean(error_slope_xy3))
  mean_error_intercept_xy3 <- c(mean_error_intercept_xy3,
                                mean(error_intercept_xy3))
}

# appending the results into the data dframe
bias_slope3 <- data.frame(mean_error_intercept_xy3 - intercept,
                          mean_error_slope_xy3 -slope,
                          mean_error_intercept_xy3,mean_error_slope_xy3,
                          length(x),intercept, slope, sigma_x,
                          sigma_y, residual)
colnames(bias_slope3) <- columns

write.csv(bias_slope3,'sigma_y.csv')



######################################################################
############################################################
# changing the slopes
x <- seq(1, 10, stepsize)
sigma_y <- 1
sigma_x <- 1
mean_error_x <- 0
mean_error_y <- 0
num_of_rep <- 1000                                  # sample size
intercept <- 0.5                                       # intercept
slope <- seq(-10, 10, stepsize)

mean_error_slope_xy4 <- c()
mean_error_intercept_xy4 <- c()
residual <- c()
#for (p in 1:length(sigma_x)) {

for (i in slope) {

  error_slope_xy4 <- numeric(num_of_rep)
  error_intercept_xy4 <- numeric(num_of_rep)
  for (k in 1:num_of_rep) {

    x_with_error = x + rnorm(length(x), mean_error_x, sigma_x)
    y_predefined <- intercept + i*x
    y_with_error = y_predefined + rnorm(length(x), mean_error_y, sigma_y)
    wzlm = lm (y_with_error ~ x_with_error)
    error_slope_xy4[[k]] = as.vector( wzlm$coefficients[2])
    error_intercept_xy4[[k]] <- as.vector( wzlm$coefficients[1])
  }

  new_y <- mean(error_intercept_xy4) + mean(error_slope_xy4)*x
  fitted_line<- summary( lm(new_y ~ x) )
  res <- fitted_line$sigma
  residual <- c(res, residual)

  mean_error_slope_xy4 <- c(mean_error_slope_xy4, mean(error_slope_xy4))
  mean_error_intercept_xy4 <- c(mean_error_intercept_xy4,
                                mean(error_intercept_xy4))
}


# appending the results into the data dframe
bias_slope4 <- data.frame(mean_error_intercept_xy4 - intercept,
                          mean_error_slope_xy4 - slope,
                          mean_error_intercept_xy4,mean_error_slope_xy4,
                          length(x),intercept, slope, sigma_x,
                          sigma_y, residual)
colnames(bias_slope4) <- columns
write.csv(bias_slope4,'slope.csv')



#######################################################
###################################################
# varying intercept

x <- seq(1, 10, stepsize)
sigma_y <- 1
sigma_x <- 1
mean_error_x <- 0
mean_error_y <- 0
num_of_rep <- 1000
n <- length(sigma_y)                                  # sample size
intercept <- seq(-10, 10, stepsize)                                       # intercept
slope <-   2

mean_error_slope_xy5 <- c()
mean_error_intercept_xy5 <- c()
residual <- c()
#for (p in 1:length(sigma_x)) {

for (i in intercept) {

  error_slope_xy5 <- numeric(num_of_rep)
  error_intercept_xy5 <- numeric(num_of_rep)
  for (k in 1:num_of_rep) {

    x_with_error = x + rnorm(length(x), mean_error_x, sigma_x)
    y_predefined <- i + slope*x
    y_with_error = y_predefined + rnorm(length(x), mean_error_y, sigma_y)
    wzlm = lm (y_with_error ~ x_with_error)
    error_slope_xy5[[k]] = as.vector( wzlm$coefficients[2])
    error_intercept_xy5[[k]] <- as.vector( wzlm$coefficients[1])
  }

  new_y <- mean(error_intercept_xy5) + mean(error_slope_xy5)*x
  fitted_line<- summary( lm(new_y ~ x) )
  res <- fitted_line$sigma
  residual <- c(res, residual)

  mean_error_slope_xy5 <- c(mean_error_slope_xy5, mean(error_slope_xy5))
  mean_error_intercept_xy5 <- c(mean_error_intercept_xy5,
                                mean(error_intercept_xy5))
}


# appending the results into the data dframe
bias_slope5 <- data.frame(mean_error_intercept_xy5 - intercept,
                          mean_error_slope_xy5 - slope,
                          mean_error_intercept_xy5,mean_error_slope_xy5,
                          length(x),intercept, slope, sigma_x,
                          sigma_y, residual)
colnames(bias_slope5) <- columns
write.csv(bias_slope5,'intercept.csv')







nrow(bias_slope1)
nrow(bias_slope2)
nrow(bias_slope3)
nrow(bias_slope4)
nrow(bias_slope5)





# # varying all parameters together
#  stepsize = 5
# x <- seq(1, 10, stepsize)
# sigma_x <- seq(0.1, 5, stepsize)
# sigma_y <- seq(0.1, 5, stepsize)
# mean_error_x <- 0
# mean_error_y <- 0
# num_of_rep <-2                       
# intercept <- seq(-10, 10, stepsize)                                     
# slope <- seq(-10, 10, stepsize)                          
# 
# mean_error_slope_xy6 <- c()
# mean_error_intercept_xy6 <- c()
# residual <- c()
# 
# for (i in x) {
#   error_slope_xy6 <- numeric()
#   error_intercept_xy6 <- numeric()
#   for (k in sigma_x) {
#     x_with_error = i + rnorm(length(x), mean_error_x, k)
#     
#     for (j in slope) { 
#       for (t in intercept) { 
#       #y_predefined <- t + j*x
#       for (s in sigma_y) {
#         y_with_error = t + j*x_with_error + rnorm(length(x), 
#                                             mean_error_y, s) 
#         for (p in 1:num_of_rep) {
#           wzlm = lm (y_with_error ~ x_with_error)  
#           error_slope_xy6[[p]] = as.vector( wzlm$coefficients[2])
#           error_intercept_xy6[[p]] = as.vector( wzlm$coefficients[1])
#         }
#       }}
#     }
#   }
#   new_y <- mean(error_intercept_xy6) + mean(error_slope_xy6)*x
#   fitted_line<- summary( lm(new_y ~ x) )
#   res <- fitted_line$sigma
#   residual <- c(res, residual)
#   
#   mean_error_slope_xy6 = c(mean_error_slope_xy6, mean(error_slope_xy6) ) 
#   mean_error_intercept_xy6 = c(mean_error_intercept_xy6,
#                                mean(error_intercept_xy6) )
# }
# 
# 
# 
# 
# intercept
# 
# 
# # appending the results into the data dframe
# bias_slope6 <- data.frame(mean_error_intercept_xy6 -intercept,
#                           mean_error_slope_xy6 - slope,
#                           mean_error_intercept_xy6,mean_error_slope_xy6,
#                           length(x), intercept, slope, residual)
# colnames(bias_slope6) <- columns 
# write.csv(bias_slope6,'varying_all_paramters1.csv')
# 
# 
